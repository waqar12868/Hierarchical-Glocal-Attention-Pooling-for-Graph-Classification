import numpy as np

# Read input files
with open('/home/waqar.ali/MultiChannelPooling-master/data/MUTAGENICITY/raw/Mutagenicity_graph_indicator.txt') as f:
    graph_indicator = np.array([int(line.strip()) for line in f.readlines()])
with open('/home/waqar.ali/MultiChannelPooling-master/data/MUTAGENICITY/raw/Mutagenicity_graph_labels.txt') as f:
    graph_labels = np.array([int(line.strip()) for line in f.readlines()])  
with open('/home/waqar.ali/MultiChannelPooling-master/data/MUTAGENICITY/raw/Mutagenicity_node_labels.txt') as f:
    node_labels = np.array([int(line.strip()) for line in f.readlines()])
with open('/home/waqar.ali/MultiChannelPooling-master/data/MUTAGENICITY/raw/Mutagenicity_A.txt') as f:
    edges = [tuple(map(int, line.strip().split(','))) for line in f.readlines()]


# Prepare to write the output file
with open('MUTAGENICITY.txt', 'w') as output_file:
    N = len(np.unique(graph_indicator))
    output_file.write(f'{N}\n')

    for graph_id in range(1, N + 1):
        nodes_in_graph = np.where(graph_indicator == graph_id)[0]
        num_nodes = len(nodes_in_graph)
        graph_label = graph_labels[graph_id - 1]
        output_file.write(f'{num_nodes} {graph_label}\n')

        # Create a list to store neighbor info for each node
        neighbors_list = {node: [] for node in nodes_in_graph}

        # Populate neighbors_list with correct edges
        for edge in edges:
            if edge[0] in nodes_in_graph and edge[1] in nodes_in_graph:
                neighbors_list[edge[0]].append(edge[1])
                neighbors_list[edge[1]].append(edge[0])

        # Write node data to the output file
        for node_id in nodes_in_graph:
            node_label = node_labels[node_id]
            neighbors = sorted(set(neighbors_list[node_id]))
            num_neighbors = len(neighbors)
            # Convert global node indices to local indices within the graph
            local_indices = [np.where(nodes_in_graph == neighbor)[0][0] for neighbor in neighbors]
            neighbors_str = ' '.join(map(str, local_indices))
            output_file.write(f'{node_label} {num_neighbors} {neighbors_str}\n')