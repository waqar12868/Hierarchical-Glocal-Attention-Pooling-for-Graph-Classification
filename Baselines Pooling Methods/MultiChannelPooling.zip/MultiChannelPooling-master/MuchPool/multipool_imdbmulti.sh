#!/bin/sh
module load python
python main2.py