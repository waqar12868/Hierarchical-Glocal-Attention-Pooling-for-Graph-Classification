#!/bin/sh
module load python
python main1.py