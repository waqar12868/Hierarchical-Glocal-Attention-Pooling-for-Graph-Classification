import networkx as nx
G = nx.path_graph(4)  # or DiGraph, MultiGraph, MultiDiGraph, etc
print(G.degree[0])  # node 0 has degree 1
print(list(G.degree([0, 1, 2])))
print(list(dict(G.degree()).values()))