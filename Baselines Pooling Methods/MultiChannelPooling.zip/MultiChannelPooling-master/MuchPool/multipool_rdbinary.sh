#!/bin/sh
module load python
python main3.py