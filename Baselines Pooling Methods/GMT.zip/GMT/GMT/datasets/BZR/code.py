import numpy as np
import scipy.sparse as sp
import os

datasets = ['BZR']

for dataset in datasets:
    path2data = '/home/waqar.ali/GMT/datasets/' + dataset + '/'  # Pat  # Path to the data folder

    # Reading graph labels
    graph_labels = np.loadtxt(f'{path2data}{dataset}_graph_labels.txt', dtype=int)
    num_graphs = len(graph_labels)


    # Splitting data into train and test sets for 10 folds
    total = len(graph_labels)
    fold_size = total // 10
    p = np.random.permutation(total)

    fold_dir = os.path.join(dataset, '10fold_idx')
    os.makedirs(fold_dir, exist_ok=True)

    for fold in range(1, 11):
        test_range = p[(fold - 1) * fold_size: fold * fold_size]
        train_range = np.concatenate([p[: (fold - 1) * fold_size], p[fold * fold_size:]])

        with open(f'{fold_dir}/test_idx-{fold}.txt', 'w') as f:
            for idx in test_range:
                f.write(f'{idx}\n')

        with open(f'{fold_dir}/train_idx-{fold}.txt', 'w') as f:
            for idx in train_range:
                f.write(f'{idx}\n')
