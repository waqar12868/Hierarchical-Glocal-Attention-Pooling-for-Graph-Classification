#!/bin/sh
export PYTHONUNBUFFERED=1
module load python
srun python wit_topopool_main_social.py