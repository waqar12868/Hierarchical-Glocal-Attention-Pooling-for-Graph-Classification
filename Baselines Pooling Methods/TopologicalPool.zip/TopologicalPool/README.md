# Topological Pooling on Graphs

### Wit-TopoPool

Code for paper "Topological Pooling on Graphs" (AAAI 2023).

### Requirements

Python 3.10, Pytorch 1.11.0, gudhi 3.5.0, networkx 2.8.4, dionysus 2.0.8, numpy 1.22.4, scipy 1.8.1, and persim 0.3.1.
